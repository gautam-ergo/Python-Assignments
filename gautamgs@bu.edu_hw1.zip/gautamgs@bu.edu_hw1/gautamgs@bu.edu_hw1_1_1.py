""" 
CS 521 Information Structures with Python
#########################################
Module          - HW 1
Creation Date   - 09/18/2018
Student Name    - Gautam Gowrishankar

Intent:
    To llustrate the print functionality.
"""

#For Displaying the current version of Python
import platform
print ("Python version being used for this code - ", platform.python_version(),'\n')


#Displaying message
print("Welcome To Python \n")
print("Welcome to Computer Science \n")
print("Programming is fun")
