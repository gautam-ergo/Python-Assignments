""" 
CS 521 Information Structures with Python
#########################################
Module          - HW 1
Creation Date   - 09/18/2018
Student Name    - Gautam Gowrishankar

Intent:
    To llustrate a pattern using print functionality.
"""

#For Displaying the current version of Python
import platform
print ("Python version being used for this code - ", platform.python_version(),'\n')


#Displaying pattern
print("FFFFFFF   U      U   NN      NN")
print("FF        U      U   NNN     NN")
print("FFFFFFF   U      U   NN N    NN")
print("FF         U    U    NN  N   NN")
print("FF          UUU      NN     NNN")
